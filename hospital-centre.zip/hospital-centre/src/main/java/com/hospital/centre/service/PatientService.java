package com.hospital.centre.service; import com.hospital.centre.dto.PatientForm; import com.hospital.centre.entity.Patient; import org.springframework.data.domain.*;
public interface PatientService { Page<Patient> search(String q,Pageable pageable); Patient get(Long id); Patient create(PatientForm f); Patient update(Long id,PatientForm f); void delete(Long id); }
