package com.hospital.centre.dto; public record DashboardVM(long todayPatients,long todayVisits,java.math.BigDecimal todayRevenue,long pendingLabs,long expiringMedicines,long lowStock) {}
