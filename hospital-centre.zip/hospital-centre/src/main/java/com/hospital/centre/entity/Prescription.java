package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class Prescription { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; @ManyToOne(optional=false) private Patient patient; @ManyToOne private Visit visit; @ManyToOne private Doctor doctor; private LocalDate prescriptionDate; private String diagnosis; @Column(length=3000) private String advice; private LocalDate followUpDate; @Enumerated(EnumType.STRING) private PrescriptionStatus status=PrescriptionStatus.ACTIVE; @OneToMany(mappedBy="prescription",cascade=CascadeType.ALL,orphanRemoval=true) private List<PrescriptionItem> items=new ArrayList<>(); }
