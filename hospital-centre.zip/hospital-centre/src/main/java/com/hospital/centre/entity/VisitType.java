package com.hospital.centre.entity;
public enum VisitType { OPD,IPD,EMERGENCY,FOLLOW_UP }
