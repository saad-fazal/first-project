package com.hospital.centre.entity;
public enum LabOrderStatus { ORDERED,SAMPLE_COLLECTED,IN_PROGRESS,COMPLETED,CANCELLED }
