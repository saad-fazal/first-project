package com.hospital.centre.entity;
public enum MovementType { PURCHASE,SALE,RETURN,ADJUSTMENT,EXPIRED_DISPOSAL }
