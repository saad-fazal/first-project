package com.hospital.centre.entity;
public enum ChargeType { CONSULTATION,LAB,PHARMACY,PROCEDURE,ROOM,OTHER }
