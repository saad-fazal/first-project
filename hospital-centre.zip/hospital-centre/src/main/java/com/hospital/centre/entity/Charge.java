package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class Charge { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; @ManyToOne(optional=false) private Patient patient; @ManyToOne private Visit visit; @Enumerated(EnumType.STRING) private ChargeType chargeType; private String description,referenceId; private BigDecimal quantity=BigDecimal.ONE,unitPrice=BigDecimal.ZERO,discount=BigDecimal.ZERO,taxPercent=BigDecimal.ZERO,netAmount=BigDecimal.ZERO; private LocalDateTime chargedAt; private String createdBy; }
