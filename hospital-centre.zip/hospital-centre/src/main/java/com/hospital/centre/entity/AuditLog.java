package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class AuditLog { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; private String entityName,entityId,performedBy; @Enumerated(EnumType.STRING) private AuditAction action; private LocalDateTime performedAt; @Column(length=4000) private String details; }
