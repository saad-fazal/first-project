package com.hospital.centre.service; import com.hospital.centre.entity.*; import java.util.*;
public interface StockService { void receive(MedicineBatch batch); void dispense(Medicine medicine,int quantity,String ref,String user); void expireDaily(); List<MedicineBatch> expiring(int days); long lowStockCount(); }
