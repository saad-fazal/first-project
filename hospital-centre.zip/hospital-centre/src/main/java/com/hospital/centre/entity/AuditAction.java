package com.hospital.centre.entity;
public enum AuditAction { CREATE,UPDATE,DELETE }
