package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class LabTest { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; @Column(unique=true,nullable=false) private String testCode; private String testName; @Enumerated(EnumType.STRING) private LabCategory category; private String sampleType; private BigDecimal price; private Integer turnaroundHours; private boolean active=true; }
