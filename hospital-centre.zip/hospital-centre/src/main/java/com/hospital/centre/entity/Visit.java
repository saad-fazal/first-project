package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class Visit { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; @ManyToOne(optional=false) private Patient patient; @ManyToOne private Doctor doctor; private LocalDateTime visitDate; @Enumerated(EnumType.STRING) private VisitType visitType; @Column(length=2000) private String chiefComplaint,diagnosis,notes; private LocalDate followUpDate; @Enumerated(EnumType.STRING) private VisitStatus status=VisitStatus.SCHEDULED; private String createdBy; private LocalDateTime createdAt; }
