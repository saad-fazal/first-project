package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class MedicineBatch { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; @ManyToOne(optional=false) private Medicine medicine; @Column(nullable=false) private String batchNumber; private LocalDate manufacturingDate,expiryDate; private Integer quantityReceived=0,quantityAvailable=0; private BigDecimal purchasePrice=BigDecimal.ZERO,sellingPrice=BigDecimal.ZERO; @ManyToOne private Supplier supplier; private LocalDate receivedDate; private String locationRack; }
