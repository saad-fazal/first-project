package com.hospital.centre.repository;
import com.hospital.centre.entity.*; import org.springframework.data.domain.*; import org.springframework.data.jpa.repository.JpaRepository; import java.time.*; import java.util.*;
public interface LabTestRepository extends JpaRepository<LabTest,Long> { Page<LabTest> findByTestNameContainingIgnoreCaseOrTestCodeContainingIgnoreCase(String a,String b,Pageable p); List<LabTest> findByActiveTrueOrderByTestNameAsc(); }
