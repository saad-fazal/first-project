package com.hospital.centre.repository;
import com.hospital.centre.entity.*; import org.springframework.data.domain.*; import org.springframework.data.jpa.repository.JpaRepository; import java.time.*; import java.util.*;
public interface VisitRepository extends JpaRepository<Visit,Long> { Page<Visit> findAllByOrderByVisitDateDesc(Pageable p); long countByVisitDateBetween(LocalDateTime a,LocalDateTime b); List<Visit> findByPatientIdOrderByVisitDateDesc(Long patientId); List<Visit> findByDoctorIdAndVisitDateBetween(Long doctorId,LocalDateTime a,LocalDateTime b); }
