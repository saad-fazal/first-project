package com.hospital.centre.config;

import com.hospital.centre.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.*;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;

@Configuration
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final UserRepository users;

    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    UserDetailsService userDetailsService() {
        return username -> users.findByUsername(username).map(u -> User.withUsername(u.getUsername()).password(u.getPassword()).disabled(!u.isEnabled()).accountLocked(!u.isAccountNonLocked()).roles(u.getRoles().stream().map(r -> r.getName().replace("ROLE_", "")).toArray(String[]::new)).build()).orElseThrow(() -> new UsernameNotFoundException(username));
    }

    @Bean
    AccessDeniedHandler accessDeniedHandler() {
        return (request, response, ex) -> response.sendRedirect("/error/403");
    }

    @Bean
    SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http.authorizeHttpRequests(a -> a.requestMatchers(
                "/css/**",
                "/js/**",
                "/login",
                "/error/**"
        ).permitAll().requestMatchers("/h2-console/**").permitAll().requestMatchers("/patients/**", "/visits/**").hasAnyRole("ADMIN", "RECEPTIONIST", "DOCTOR").requestMatchers("/medical-records/**", "/prescriptions/**").hasAnyRole("ADMIN", "DOCTOR").requestMatchers("/lab/**").hasAnyRole("ADMIN", "DOCTOR", "LAB_TECH").requestMatchers("/pharmacy/**").hasAnyRole("ADMIN", "PHARMACIST").requestMatchers("/billing/**", "/reports/revenue/**").hasAnyRole("ADMIN", "RECEPTIONIST", "ACCOUNTANT").anyRequest().authenticated()).formLogin(f -> f.loginPage("/login").defaultSuccessUrl("/", true).permitAll()).logout(l -> l.logoutSuccessUrl("/login?logout").permitAll()).exceptionHandling(e -> e.accessDeniedHandler(accessDeniedHandler())).rememberMe(r -> r.tokenValiditySeconds(86400).key("hospital-centre-key")).csrf(c -> c.ignoringRequestMatchers("/h2-console/**")).headers(h -> h.frameOptions(f -> f.sameOrigin())).build();
    }
}
