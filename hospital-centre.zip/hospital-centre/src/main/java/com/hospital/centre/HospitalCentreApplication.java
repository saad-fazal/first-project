package com.hospital.centre;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class HospitalCentreApplication {
    public static void main(String[] args) { SpringApplication.run(HospitalCentreApplication.class, args); }
}
