package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class Patient { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; @Column(unique=true,nullable=false) private String mrn; @Column(nullable=false) private String firstName,lastName; @Enumerated(EnumType.STRING) private Gender gender; private LocalDate dateOfBirth; @Enumerated(EnumType.STRING) private BloodGroup bloodGroup; private String phone,alternatePhone,email,address,city,emergencyContactName,emergencyContactPhone,allergies,chronicConditions; private LocalDate registrationDate; private boolean active=true; private String photoPath; @Transient public int getAge(){ if(dateOfBirth==null)return 0; return Period.between(dateOfBirth,LocalDate.now()).getYears(); } }
