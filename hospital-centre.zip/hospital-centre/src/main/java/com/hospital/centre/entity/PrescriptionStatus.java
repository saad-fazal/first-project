package com.hospital.centre.entity;
public enum PrescriptionStatus { ACTIVE,COMPLETED,CANCELLED }
