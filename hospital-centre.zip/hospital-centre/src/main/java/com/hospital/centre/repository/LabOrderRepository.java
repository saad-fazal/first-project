package com.hospital.centre.repository;
import com.hospital.centre.entity.*; import org.springframework.data.domain.*; import org.springframework.data.jpa.repository.JpaRepository; import java.time.*; import java.util.*;
public interface LabOrderRepository extends JpaRepository<LabOrder,Long> { Page<LabOrder> findAllByOrderByOrderedDateDesc(Pageable p); List<LabOrder> findByPatientIdOrderByOrderedDateDesc(Long id); long countByStatusNot(LabOrderStatus status); }
