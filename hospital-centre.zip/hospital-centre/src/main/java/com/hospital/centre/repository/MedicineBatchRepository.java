package com.hospital.centre.repository;

import com.hospital.centre.entity.MedicineBatch;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;

public interface MedicineBatchRepository extends JpaRepository<MedicineBatch, Long> {

    /*
     * All batches for a medicine ordered by earliest expiry first.
     * Used by reports and stock/FEFO processing.
     */
    List<MedicineBatch> findByMedicineIdOrderByExpiryDateAsc(Long medicineId);

    /*
     * Available, non-expired batches for a medicine.
     * FEFO: earliest expiry date first.
     */
    List<MedicineBatch>
    findByMedicineIdAndQuantityAvailableGreaterThanAndExpiryDateGreaterThanOrderByExpiryDateAsc(
            Long medicineId,
            int quantityAvailable,
            LocalDate expiryDate
    );

    /*
     * Find batches that have expired and still have stock.
     */
    List<MedicineBatch>
    findByExpiryDateBeforeAndQuantityAvailableGreaterThan(
            LocalDate expiryDate,
            int quantityAvailable
    );

    /*
     * Batches expiring between two dates.
     */
    List<MedicineBatch> findByExpiryDateBetween(
            LocalDate from,
            LocalDate to
    );

    /*
     * Batches expired before a specific date.
     */
    List<MedicineBatch> findByExpiryDateBefore(
            LocalDate date
    );

    /*
     * Batches within a date range having available stock.
     */
    List<MedicineBatch>
    findByExpiryDateBetweenAndQuantityAvailableGreaterThan(
            LocalDate from,
            LocalDate to,
            int quantity
    );

    /*
     * Available batches ordered by expiry.
     */
    List<MedicineBatch>
    findByQuantityAvailableGreaterThanOrderByExpiryDateAsc(
            int quantity
    );

    /*
     * FEFO query.
     */
    @Query("""
        SELECT b
        FROM MedicineBatch b
        WHERE b.quantityAvailable > 0
        ORDER BY b.expiryDate ASC
    """)
    List<MedicineBatch> findAvailableBatchesForFefo();
}