package com.hospital.centre.entity;
public enum MedicineForm { TABLET,SYRUP,INJECTION,OINTMENT,CAPSULE,OTHER }
