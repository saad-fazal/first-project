package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class Payment { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; @ManyToOne(optional=false) private Invoice invoice; private BigDecimal amount; private LocalDateTime paymentDate; @Enumerated(EnumType.STRING) private PaymentMode paymentMode; private String referenceNumber,receivedBy; }
