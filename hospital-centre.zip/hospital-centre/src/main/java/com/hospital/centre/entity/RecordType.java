package com.hospital.centre.entity;
public enum RecordType { CONSULTATION,PROCEDURE,VACCINATION,SURGERY,ALLERGY_NOTE }
