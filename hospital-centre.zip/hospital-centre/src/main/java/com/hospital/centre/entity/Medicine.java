package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class Medicine { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; @Column(unique=true,nullable=false) private String medicineCode; @Column(nullable=false) private String name; private String genericName,brand,category; @Enumerated(EnumType.STRING) private MedicineForm form; private String strength,unit,manufacturer,hsnCode; private BigDecimal taxPercent=BigDecimal.ZERO; private Integer reorderLevel=0; private boolean active=true; }
