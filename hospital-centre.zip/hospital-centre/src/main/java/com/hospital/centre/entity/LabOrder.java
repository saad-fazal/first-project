package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class LabOrder { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; @Column(unique=true,nullable=false) private String orderNumber; @ManyToOne(optional=false) private Patient patient; @ManyToOne private Doctor doctor; @ManyToOne private Visit visit; private LocalDateTime orderedDate; @Enumerated(EnumType.STRING) private LabOrderStatus status=LabOrderStatus.ORDERED; @Enumerated(EnumType.STRING) private Priority priority=Priority.ROUTINE; private BigDecimal totalAmount=BigDecimal.ZERO; private String remarks; @OneToMany(mappedBy="labOrder",cascade=CascadeType.ALL,orphanRemoval=true) private List<LabOrderItem> items=new ArrayList<>(); }
