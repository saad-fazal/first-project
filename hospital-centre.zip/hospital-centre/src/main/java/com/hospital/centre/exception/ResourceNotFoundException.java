package com.hospital.centre.exception; public class ResourceNotFoundException extends RuntimeException{public ResourceNotFoundException(String m){super(m);}}
