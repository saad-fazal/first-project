package com.hospital.centre.entity;
public enum LabItemStatus { ORDERED,SAMPLE_COLLECTED,IN_PROGRESS,COMPLETED,CANCELLED }
