package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class StockMovement { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; @ManyToOne(optional=false) private Medicine medicine; @ManyToOne private MedicineBatch batch; @Enumerated(EnumType.STRING) private MovementType movementType; private Integer quantity; private String referenceType,referenceId,notes,createdBy; private LocalDateTime createdAt; }
