package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class LabOrderItem { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; @ManyToOne(optional=false) private LabOrder labOrder; @ManyToOne(optional=false) private LabTest labTest; @Enumerated(EnumType.STRING) private LabItemStatus status=LabItemStatus.ORDERED; private String resultValue,unit,normalRange; @Enumerated(EnumType.STRING) private ResultFlag resultFlag; private String remarks,verifiedBy,reportFilePath; private LocalDateTime verifiedAt; }
