package com.hospital.centre.dto; import jakarta.validation.constraints.*; import java.time.*;
public record PrescriptionForm(@NotNull Long patientId,Long visitId,@NotNull Long doctorId,@NotBlank String diagnosis,@NotBlank String advice,LocalDate followUpDate) {}
