package com.hospital.centre.entity;
public enum Gender { MALE,FEMALE,OTHER }
