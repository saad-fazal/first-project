package com.hospital.centre.exception; public class BusinessException extends RuntimeException{public BusinessException(String m){super(m);}}
