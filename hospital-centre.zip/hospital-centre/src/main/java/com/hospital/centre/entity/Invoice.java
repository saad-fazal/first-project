package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class Invoice { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; @Column(unique=true,nullable=false) private String invoiceNumber; @ManyToOne(optional=false) private Patient patient; @ManyToOne private Visit visit; private LocalDate invoiceDate; private BigDecimal subTotal=BigDecimal.ZERO,discount=BigDecimal.ZERO,tax=BigDecimal.ZERO,grandTotal=BigDecimal.ZERO,paidAmount=BigDecimal.ZERO,balance=BigDecimal.ZERO; @Enumerated(EnumType.STRING) private PaymentMode paymentMode; @Enumerated(EnumType.STRING) private PaymentStatus paymentStatus=PaymentStatus.UNPAID; private String remarks; @OneToMany(mappedBy="invoice",cascade=CascadeType.ALL,orphanRemoval=true) private List<Payment> payments=new ArrayList<>(); }
