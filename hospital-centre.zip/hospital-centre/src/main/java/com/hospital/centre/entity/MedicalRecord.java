package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class MedicalRecord { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; @ManyToOne(optional=false) private Patient patient; @ManyToOne private Visit visit; private LocalDate recordDate; @Enumerated(EnumType.STRING) private RecordType recordType; private String title; @Column(length=4000) private String description; private BigDecimal height,weight,bmi; private String bp; private Integer pulse; private BigDecimal temperature,spo2; private String attachments,recordedBy; }
