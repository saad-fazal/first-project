package com.hospital.centre.service.impl;

import com.hospital.centre.entity.Invoice;
import com.hospital.centre.entity.LabOrder;
import com.hospital.centre.entity.Medicine;
import com.hospital.centre.entity.MedicineBatch;
import com.hospital.centre.entity.Prescription;
import com.hospital.centre.entity.Visit;
import com.hospital.centre.repository.InvoiceRepository;
import com.hospital.centre.repository.LabOrderRepository;
import com.hospital.centre.repository.MedicineBatchRepository;
import com.hospital.centre.repository.MedicineRepository;
import com.hospital.centre.repository.PrescriptionRepository;
import com.hospital.centre.repository.VisitRepository;
import com.hospital.centre.service.ReportService;

import com.lowagie.text.Document;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;

import com.opencsv.CSVWriter;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.StringWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service @RequiredArgsConstructor public class ReportServiceImpl implements ReportService {private final VisitRepository visitsRepo;private final InvoiceRepository invoiceRepo;private final LabOrderRepository labRepo;private final PrescriptionRepository rxRepo;private final MedicineBatchRepository batchRepo;private final MedicineRepository medRepo;
 public List<Visit> visits(LocalDate f,LocalDate t){return visitsRepo.findAll().stream().filter(v->!v.getVisitDate().toLocalDate().isBefore(f)&&!v.getVisitDate().toLocalDate().isAfter(t)).toList();} public List<Invoice> invoices(LocalDate f,LocalDate t){return invoiceRepo.findByInvoiceDateBetween(f,t);} public List<LabOrder> labs(){return labRepo.findAll();} public List<Prescription> prescriptions(){return rxRepo.findAll();} public List<MedicineBatch> expiry(LocalDate d,int days){return batchRepo.findByExpiryDateBetween(d,d.plusDays(days));} public List<Medicine> lowStock(){return medRepo.findAll().stream().filter(m->batchRepo.findByMedicineIdOrderByExpiryDateAsc(m.getId()).stream().mapToInt(MedicineBatch::getQuantityAvailable).sum()<=m.getReorderLevel()).toList();}
 public byte[] csv(String title,List<String[]> rows){try(StringWriter sw=new StringWriter();CSVWriter w=new CSVWriter(sw)){w.writeNext(new String[]{title});rows.forEach(w::writeNext);return sw.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);}catch(Exception e){throw new IllegalStateException(e);}}
 public byte[] pdf(String title,List<String[]> rows){try(ByteArrayOutputStream out=new ByteArrayOutputStream()){Document d=new Document(PageSize.A4);PdfWriter.getInstance(d,out);d.open();d.add(new Paragraph(title));d.add(new Paragraph("Generated: "+LocalDateTime.now()));for(String[] r:rows)d.add(new Paragraph(String.join(" | ",r)));d.close();return out.toByteArray();}catch(Exception e){throw new IllegalStateException(e);}}
}
