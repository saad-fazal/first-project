package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class Doctor { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; @Column(unique=true,nullable=false) private String employeeCode; private String firstName,lastName,specialization,qualification,phone,email,department; private BigDecimal consultationFee=BigDecimal.ZERO; private boolean active=true; }
