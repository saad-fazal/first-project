package com.hospital.centre.entity;
public enum PaymentMode { CASH,CARD,UPI,INSURANCE }
