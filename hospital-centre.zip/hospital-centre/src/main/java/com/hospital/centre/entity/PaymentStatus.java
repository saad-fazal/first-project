package com.hospital.centre.entity;
public enum PaymentStatus { PAID,PARTIAL,UNPAID }
