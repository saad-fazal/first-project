package com.hospital.centre.dto; import com.hospital.centre.entity.*; import jakarta.validation.constraints.*; import java.time.*;
public record VisitForm(@NotNull Long patientId,@NotNull Long doctorId,@NotNull LocalDateTime visitDate,@NotNull VisitType visitType,@NotBlank String chiefComplaint,String diagnosis,String notes,LocalDate followUpDate,VisitStatus status) {}
