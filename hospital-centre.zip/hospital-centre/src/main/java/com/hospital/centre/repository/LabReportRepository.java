package com.hospital.centre.repository;
import com.hospital.centre.entity.*; import org.springframework.data.domain.*; import org.springframework.data.jpa.repository.JpaRepository; import java.time.*; import java.util.*;
public interface LabReportRepository extends JpaRepository<LabReport,Long> { List<LabReport> findByLabOrderPatientIdOrderByReportDateDesc(Long id); }
