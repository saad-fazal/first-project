package com.hospital.centre.entity;
public enum ResultFlag { NORMAL,HIGH,LOW,CRITICAL }
