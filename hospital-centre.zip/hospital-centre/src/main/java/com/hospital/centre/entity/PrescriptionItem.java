package com.hospital.centre.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.math.BigDecimal;
import java.util.*;

@Entity @Getter @Setter @NoArgsConstructor
public class PrescriptionItem { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; @ManyToOne(optional=false) private Prescription prescription; @ManyToOne(optional=false) private Medicine medicine; private String dosage,frequency; private Integer durationDays; private String route,instructions; private Integer quantity; }
