package com.hospital.centre.entity;
public enum VisitStatus { SCHEDULED,IN_PROGRESS,COMPLETED,CANCELLED }
