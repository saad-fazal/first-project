package com.hospital.centre.repository;
import com.hospital.centre.entity.*; import org.springframework.data.domain.*; import org.springframework.data.jpa.repository.JpaRepository; import java.time.*; import java.util.*;
public interface ChargeRepository extends JpaRepository<Charge,Long> { List<Charge> findByPatientIdOrderByChargedAtDesc(Long id); List<Charge> findByChargedAtBetween(LocalDateTime a,LocalDateTime b); }
