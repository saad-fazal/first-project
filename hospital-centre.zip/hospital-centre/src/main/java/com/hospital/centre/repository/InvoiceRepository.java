package com.hospital.centre.repository;
import com.hospital.centre.entity.*; import org.springframework.data.domain.*; import org.springframework.data.jpa.repository.JpaRepository; import java.time.*; import java.util.*;
public interface InvoiceRepository extends JpaRepository<Invoice,Long> { Page<Invoice> findByPaymentStatusNotOrderByInvoiceDateDesc(PaymentStatus status,Pageable p); List<Invoice> findByPatientIdOrderByInvoiceDateDesc(Long id); List<Invoice> findByInvoiceDateBetween(LocalDate a,LocalDate b); }
