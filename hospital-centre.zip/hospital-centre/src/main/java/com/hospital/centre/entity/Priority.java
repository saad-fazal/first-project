package com.hospital.centre.entity;
public enum Priority { ROUTINE,URGENT }
