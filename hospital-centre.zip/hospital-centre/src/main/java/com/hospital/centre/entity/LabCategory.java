package com.hospital.centre.entity;
public enum LabCategory { HAEMATOLOGY,BIOCHEMISTRY,RADIOLOGY,MICROBIOLOGY,SEROLOGY,PATHOLOGY,OTHER }
