package com.hospital.centre.service;

import com.hospital.centre.dto.PatientForm;
import com.hospital.centre.entity.BloodGroup;
import com.hospital.centre.entity.Gender;
import com.hospital.centre.entity.Patient;
import com.hospital.centre.repository.PatientRepository;
import com.hospital.centre.service.impl.PatientServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PatientServiceTest {

    @Mock
    private PatientRepository patientRepository;

    @InjectMocks
    private PatientServiceImpl patientService;

    @Test
    void createPatient_shouldSavePatient() {

        PatientForm form = new PatientForm(
                "Ali",
                "Khan",
                Gender.MALE,
                LocalDate.of(1990, 1, 1),
                BloodGroup.O_POSITIVE,
                "03001234567",
                null,
                "ali@example.com",
                "Main Road",
                "Karachi",
                "Ahmed Khan",
                "03111234567",
                null,
                null,
                true
        );

        Patient saved = new Patient();
        saved.setId(1L);
        saved.setFirstName("Ali");
        saved.setLastName("Khan");

        when(patientRepository.save(any(Patient.class)))
                .thenReturn(saved);

        Patient result = patientService.create(form);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Ali", result.getFirstName());
        assertEquals("Khan", result.getLastName());

        verify(patientRepository, times(1))
                .save(any(Patient.class));
    }

    @Test
    void findById_shouldReturnPatient() {

        Patient patient = new Patient();
        patient.setId(1L);
        patient.setFirstName("Ali");
        patient.setLastName("Khan");

        when(patientRepository.findById(1L))
                .thenReturn(Optional.of(patient));

        Patient result = patientService.get(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Ali", result.getFirstName());

        verify(patientRepository, times(1))
                .findById(1L);
    }
}