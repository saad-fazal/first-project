# Local Hospital Centre

Spring Boot 3.2.x / Java 17 / Thymeleaf MVC / Spring Security 6 / JPA-Hibernate / file H2.

## Prerequisites
- JDK 17
- Maven 3.9+
- Internet access on first Maven build for dependencies/CDN assets, or provide the dependencies in your Maven repository.

## Run
```bash
mvn spring-boot:run
```
For the development profile:
```bash
mvn spring-boot:run -Dspring-boot.run.profiles=dev
```
Then open `http://localhost:8080/login`.

## Database
- H2 JDBC URL: `jdbc:h2:file:./data/hospitaldb`
- Username: `sa`
- Password: blank
- Dev H2 console: `http://localhost:8080/h2-console`
- Enter the JDBC URL exactly as above.

## Default users
| Username | Password | Role |
|---|---|---|
| admin | admin123 | ADMIN |
| doctor | doctor123 | DOCTOR |
| reception | reception123 | RECEPTIONIST |
| lab | lab123 | LAB_TECH |
| pharmacy | pharm123 | PHARMACIST |
| accounts | accounts123 | ACCOUNTANT |

## Modules
- Dashboard: daily patients/visits/revenue, pending labs, expiry and low-stock KPIs.
- Patients: paginated search, profile and related visits/records/prescriptions/labs/charges.
- Visits: OPD/IPD/emergency/follow-up registration and completion.
- Medical records: vitals and BMI calculation.
- Prescriptions: doctor/patient prescription and print view; stock service supports FEFO dispensing.
- Laboratory: catalogue, multi-test orders, result entry and verification, status workflow.
- Pharmacy: medicines, suppliers, batches, stock ledger and expiry scheduler.
- Billing: charges, invoices and partial payments.
- Reports: visit, invoice/revenue, expiry and low-stock screens plus CSV/PDF visit export.

## Routes
`/`, `/login`, `/patients`, `/patients/new`, `/patients/{id}`, `/visits`, `/visits/new`, `/medical-records/new`, `/prescriptions/new`, `/prescriptions/{id}`, `/lab/tests`, `/lab/tests/new`, `/lab/orders`, `/lab/orders/new`, `/lab/orders/{id}`, `/pharmacy/medicines`, `/pharmacy/medicines/new`, `/pharmacy/suppliers`, `/pharmacy/suppliers/new`, `/pharmacy/batches`, `/pharmacy/stock`, `/billing/charges`, `/billing/charges/new`, `/billing/invoices`, `/billing/invoices/new`, `/billing/payments`, `/reports`, `/reports/visits`, `/reports/invoices`, `/reports/expiry`, `/reports/low-stock`, `/reports/export/visits.csv`, `/reports/export/visits.pdf`, `/h2-console` (dev).

## Security
Form login, BCrypt passwords, CSRF enabled, remember-me, URL and method-level authorization, role-aware Thymeleaf navigation, custom error pages, and server-side FEFO/expiry validation.

## Production notes
Change all seed passwords before deployment, use HTTPS, restrict `/h2-console`, move uploads to managed storage, configure a proper database, and use a production secrets mechanism rather than source configuration.
